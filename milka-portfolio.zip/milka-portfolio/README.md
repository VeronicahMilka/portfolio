# Milka Wanjiku Migichi | Portfolio

A minimalist personal portfolio built from scratch with HTML5, CSS and JavaScript.

## Structure

```
index.html
css/styles.css
js/main.js
```

## Run locally

Open `index.html` in your browser, or serve the folder with any static server.

## Before publishing

Search the project for `TODO` and replace the placeholder email, phone, location, GitHub links and project details.

## Design

- Background `#FAFAFA`, text `#2B2B2B`
- Sage green accent `#8A9A5B` (a deeper `#647341` is used for sage text so it stays readable)
- Fraunces for headings, Hanken Grotesk for body text
